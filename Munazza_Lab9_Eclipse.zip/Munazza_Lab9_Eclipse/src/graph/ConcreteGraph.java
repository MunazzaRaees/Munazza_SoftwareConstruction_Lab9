/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * A concrete implementation of the Graph interface.
 * 
 * @param <L> the type of labels for the vertices in the graph
 */
public class ConcreteGraph<L> implements Graph<L> {
    
    // Internal adjacency map to store edges and their weights
    private final Map<L, Map<L, Integer>> adjacencyMap;
    
    /**
     * Constructs an empty ConcreteGraph.
     */
    public ConcreteGraph() {
        this.adjacencyMap = new HashMap<>();
    }
    
    /**
     * Adds a vertex to the graph.
     *
     * @param vertex label for the new vertex
     * @return true if the graph did not already contain the vertex, false otherwise
     */
    @Override
    public boolean add(L vertex) {
        if (vertex == null) {
            throw new IllegalArgumentException("Vertex cannot be null");
        }
        if (adjacencyMap.containsKey(vertex)) {
            return false;
        }
        adjacencyMap.put(vertex, new HashMap<>());
        return true;
    }
    
    /**
     * Adds, updates, or removes a directed edge with a specified weight.
     *
     * @param source label of the source vertex
     * @param target label of the target vertex
     * @param weight non-negative weight of the edge
     * @return the previous weight of the edge, or 0 if no such edge existed
     */
    @Override
    public int set(L source, L target, int weight) {
        if (source == null || target == null) {
            throw new IllegalArgumentException("Source and target cannot be null");
        }
        if (weight < 0) {
            throw new IllegalArgumentException("Weight cannot be negative");
        }
        
        // Ensure both vertices exist in the graph
        this.add(source);
        this.add(target);
        
        Map<L, Integer> edgesFromSource = adjacencyMap.get(source);
        int previousWeight = edgesFromSource.getOrDefault(target, 0);
        
        if (weight == 0) {
            edgesFromSource.remove(target);
        } else {
            edgesFromSource.put(target, weight);
        }
        
        return previousWeight;
    }
    
    /**
     * Removes a vertex and all associated edges from the graph.
     *
     * @param vertex label of the vertex to remove
     * @return true if the vertex was present and removed, false otherwise
     */
    @Override
    public boolean remove(L vertex) {
        if (vertex == null) {
            throw new IllegalArgumentException("Vertex cannot be null");
        }
        if (!adjacencyMap.containsKey(vertex)) {
            return false;
        }
        
        // Remove the vertex and all outgoing edges
        adjacencyMap.remove(vertex);
        
        // Remove all incoming edges to this vertex
        for (Map<L, Integer> edges : adjacencyMap.values()) {
            edges.remove(vertex);
        }
        
        return true;
    }
    
    /**
     * Retrieves all vertices in the graph.
     *
     * @return a set containing all vertex labels
     */
    @Override
    public Set<L> vertices() {
        return new HashSet<>(adjacencyMap.keySet());
    }
    
    /**
     * Retrieves all source vertices that have edges pointing to the specified target.
     *
     * @param target the target vertex label
     * @return a map where keys are source vertices and values are the weights of the edges
     */
    @Override
    public Map<L, Integer> sources(L target) {
        if (target == null) {
            throw new IllegalArgumentException("Target cannot be null");
        }
        Map<L, Integer> sources = new HashMap<>();
        for (Map.Entry<L, Map<L, Integer>> entry : adjacencyMap.entrySet()) {
            L source = entry.getKey();
            Map<L, Integer> edges = entry.getValue();
            if (edges.containsKey(target)) {
                sources.put(source, edges.get(target));
            }
        }
        return sources;
    }
    
    /**
     * Retrieves all target vertices that the specified source points to.
     *
     * @param source the source vertex label
     * @return a map where keys are target vertices and values are the weights of the edges
     */
    @Override
    public Map<L, Integer> targets(L source) {
        if (source == null) {
            throw new IllegalArgumentException("Source cannot be null");
        }
        Map<L, Integer> targets = adjacencyMap.get(source);
        if (targets == null) {
            return new HashMap<>();
        }
        return new HashMap<>(targets);
    }
    
    /**
     * Provides a string representation of the graph for debugging purposes.
     *
     * @return a string detailing all vertices and their outgoing edges
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Graph {\n");
        for (Map.Entry<L, Map<L, Integer>> entry : adjacencyMap.entrySet()) {
            sb.append("  ").append(entry.getKey()).append(" -> ").append(entry.getValue()).append("\n");
        }
        sb.append("}");
        return sb.toString();
    }
}
