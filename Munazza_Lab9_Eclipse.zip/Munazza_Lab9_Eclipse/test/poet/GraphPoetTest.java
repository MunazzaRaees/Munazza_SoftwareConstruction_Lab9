/* Copyright (c) 2015-2016 MIT 6.005 course staff, all rights reserved.
 * Redistribution of original or derived work requires permission of course staff.
 */
package poet;

import static org.junit.Assert.*;

import org.junit.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Tests for GraphPoet.
 */
public class GraphPoetTest {
    
    /**
     * Helper method to create a temporary corpus file with specified content.
     *
     * @param filename name of the file
     * @param content content to write into the file
     * @throws IOException if an I/O error occurs
     */
    private void createCorpusFile(String filename, String content) throws IOException {
        File file = new File("test/" + filename);
        file.getParentFile().mkdirs(); // Ensure the 'test' directory exists
        FileWriter writer = new FileWriter(file);
        writer.write(content);
        writer.close();
    }

    /**
     * Test that assertions are enabled.
     */
    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled() {
        assert false : "Assertions should be enabled";
    }

    /**
     * Test correct handling of input files for graph construction.
     */
    @Test
    public void testInputFileHandling() throws IOException {
        String corpus = "Graph from construction test.";
        createCorpusFile("inputFile.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/inputFile.txt"));
        String input = "Graph construction test.";
        String expected = "Graph from construction test.";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test correct generation of poems with bridge words.
     */
    @Test
    public void testBasicPoemGeneration() throws IOException {
        String corpus = "Test of the system.";
        createCorpusFile("basic.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/basic.txt"));
        String input = "Test the system.";
        String expected = "Test of the system.";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test poem generation without any bridge words.
     */
    @Test
    public void testNoBridgeWords() throws IOException {
        String corpus = "No meaningful bridges here.";
        createCorpusFile("noBridge.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/noBridge.txt"));
        String input = "Hello world.";
        String expected = "Hello world.";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test handling of empty input strings.
     */
    @Test
    public void testEmptyInput() throws IOException {
        String corpus = "This is a basic corpus.";
        createCorpusFile("basicEmpty.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/basicEmpty.txt"));
        String input = "";
        String expected = "";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test handling of simple input strings with no bridge words.
     */
    @Test
    public void testSimpleInput() throws IOException {
        String corpus = "No bridge words available.";
        createCorpusFile("simpleInput.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/simpleInput.txt"));
        String input = "A simple input.";
        String expected = "A simple input.";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test case insensitivity in graph construction and poem generation.
     */
    @Test
    public void testCaseInsensitivity() throws IOException {
        String corpus = "test of the SYSTEM.";
        createCorpusFile("caseInsensitive.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/caseInsensitive.txt"));
        String input = "tEsT The System.";
        String expected = "tEsT of the System.";
    }

    /**
     * Test handling of input strings with special characters.
     */
    @Test
    public void testSpecialCharacters() throws IOException {
        String corpus = "Hello, my world!";
        createCorpusFile("specialCharacters.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/specialCharacters.txt"));
        String input = "Hello, world!";
        String expected = "Hello, my world!";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test generation of poems with bridge words inserted in the middle.
     */
    @Test
    public void testBridgeWordsInMiddle() throws IOException {
        String corpus = "A very quick brown fox jumps over.";
        createCorpusFile("bridgeMiddle.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/bridgeMiddle.txt"));
        String input = "A quick brown fox.";
        String expected = "A very quick brown fox.";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test validation for edge cases with single-word input.
     */
    @Test
    public void testSingleWordInput() throws IOException {
        String corpus = "Hello, my world!";
        createCorpusFile("singleWord.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/singleWord.txt"));
        String input = "Hello";
        String expected = "Hello";
        assertEquals(expected, poet.poem(input));
    }

    /**
     * Test handling of input where bridge words are repeated multiple times.
     */
    @Test
    public void testRepeatedBridgeWords() throws IOException {
        String corpus = "A great test amazing example.";
        createCorpusFile("repeatedBridge.txt", corpus);
        
        GraphPoet poet = new GraphPoet(new File("test/repeatedBridge.txt"));
        String input = "A test example.";
        String expected = "A great test amazing example.";
        assertEquals(expected, poet.poem(input));
    }
}
